# Texto para el informe · Frontend público

## 1. Metodología BEM (3 ejemplos)

Las clases siguen la convención **Bloque__Elemento--Modificador**.

| Ejemplo | Bloque | Elemento | Modificador | Dónde se usa |
|---|---|---|---|---|
| `card-mod__title--featured` | `card-mod` (tarjeta de servicio) | `title` (título) | `featured` (tarjeta destacada) | Tarjeta "Libreta y pensiones" en la galería y el catálogo |
| `site-nav__link--active` | `site-nav` (barra de navegación) | `link` (enlace) | `active` (página actual) | Enlace de la sección donde se está |
| `form__control--invalid` | `form` (formulario) | `control` (campo) | `invalid` (con error) | Campo que falló la validación, se pinta con borde rojo |

Otros bloques del proyecto: `hero`, `feature`, `step`, `testimonial`, `agenda`, `tabs`, `catalog-filters`, `auth`, `detail`, `site-footer`.

## 2. Framework CSS: Bootstrap 5

Se eligió **Bootstrap 5.3** para las páginas públicas porque:

- Entrega la **grilla de 12 columnas** (`row`, `col-md-6`, `col-lg-4`) con puntos de quiebre móvil, tablet y escritorio ya resueltos.
- Incluye los **componentes base** que pide el entregable: navbar con menú colapsable en móvil (`navbar`, `navbar-toggler`), botones (`btn`) y badges (`badge`).
- Se personaliza con **variables CSS** (`--bs-btn-bg`, `--bs-body-font-family`), así que se adapta a la paleta del colegio sin reescribir el framework.
- Es el más documentado y es JavaScript sin dependencias (el menú móvil funciona con `bootstrap.bundle`).
- Tailwind exige un paso de compilación o clases muy largas en el HTML; para un sitio estático de entrega académica, Bootstrap es más directo.

Las clases propias (BEM) van encima de Bootstrap y se escriben solo cuando el framework no cubre el caso. Las páginas internas del sistema (`frontend/pages/`) siguen con Bulma.

## 3. Funciones CSS nativas y variables

- `:root` en `style.css` define 40 variables (colores, fuentes, espaciados, radios, sombras, transición).
- `clamp()`: `--titulo-hero`, `--titulo-seccion` y `--texto-fluido` (tipografía fluida).
- `calc()`: espaciados como `calc(var(--espacio-xl) - var(--espacio-sm))` en `.landing-section__head`.
- `min()` / `max()`: `min-height: min(34rem, 80vh)` en `.hero` y `padding-inline: max(var(--espacio-md), 5vw)` en las secciones.

## 4. Accesibilidad

- Todas las imágenes tienen `alt` descriptivo; los íconos decorativos llevan `aria-hidden="true"`.
- Formularios (contacto, login, registro): cada campo tiene `<label for>`, `aria-required="true"`, `aria-describedby` apuntando a su mensaje de error y el mensaje con `role="alert"` (oculto con `hidden` hasta que falla la validación). Los campos inválidos reciben `aria-invalid="true"` y el foco pasa al primero con error.
- Se añadió enlace "Saltar al contenido", foco visible, `aria-current="page"` en la navegación y pestañas con `role="tablist"`.
- **Contraste:** el ocre `#b9822b` con texto blanco daba 3.34:1 y no cumplía. Los textos y botones usan ahora `--ocre-oscuro` `#8a5a10` (5.91:1 sobre blanco). Medición de todos los textos visibles de las 5 páginas públicas: el valor más bajo es 5.17:1 (mínimo exigido 4.5:1).

## 5. Lighthouse (pendiente: captura propia)

1. Abrir la página con Live Server (con internet, por Bootstrap y Font Awesome).
2. DevTools → pestaña Lighthouse → categoría **Accessibility** → *Analyze page load*.
3. Repetir al menos en `index.html` y `login.html`; pegar la captura con el puntaje en el informe (mínimo exigido: 85).
