// catalogo-data.js
// Datos de los módulos del portal. Los usan catalogo.html y producto.html,
// así que para agregar o editar un servicio solo se cambia este archivo.

const MODULOS = [
    {
        id: 'admision',
        nombre: 'Admisión',
        resumen: 'Postulación y evaluación de nuevos estudiantes.',
        descripcion: 'Gestiona todo el proceso de ingreso: desde la solicitud del postulante hasta su aprobación, sin papeles ni filas.',
        imagen: 'admision.jpg',
        ancho: 1400, alto: 633,
        alt: 'Estudiantes rindiendo su evaluación de admisión',
        icono: 'fa-file-signature',
        audiencias: ['Administración'],
        roles: 'Administrador',
        pagina: 'admision.html',
        funciones: [
            'Registro de postulantes nuevos y de traslado',
            'Seguimiento del estado: pendiente, en evaluación o aprobado',
            'Paso directo a matrícula cuando el postulante es aprobado'
        ],
        reglas: 'Cierre de admisión el 15 de enero',
        pasos: ['Registrar la solicitud', 'Evaluar al postulante', 'Aprobar y derivar a matrícula']
    },
    {
        id: 'matricula',
        nombre: 'Matrícula',
        resumen: 'Asignación de vacantes y secciones por grado.',
        descripcion: 'Asigna a cada estudiante su grado y su sección controlando el aforo, para que ningún aula pase del límite.',
        imagen: 'matricula.jpg',
        ancho: 1400, alto: 764,
        alt: 'Estudiantes y plataforma digital de matrícula',
        icono: 'fa-graduation-cap',
        audiencias: ['Administración'],
        roles: 'Administrador',
        pagina: 'matricula.html',
        funciones: [
            'Asignación de grado (1.° a 5.° de secundaria) y sección',
            'Control automático del aforo de cada sección',
            'Vacantes disponibles a la vista'
        ],
        reglas: 'Máximo de 25 alumnos por sección',
        pasos: ['Elegir al estudiante aprobado', 'Seleccionar grado y sección', 'Confirmar la matrícula']
    },
    {
        id: 'asistencia',
        nombre: 'Asistencia',
        resumen: 'Registro diario y justificación de inasistencias.',
        descripcion: 'Toma la asistencia del día desde cualquier dispositivo y deja que coordinación revise y justifique las faltas.',
        imagen: 'asistencia.jpg',
        ancho: 1400, alto: 764,
        alt: 'Docente con tablet tomando asistencia',
        icono: 'fa-calendar-check',
        audiencias: ['Docentes', 'Administración'],
        roles: 'Administrador, Profesor, Auxiliar / Coordinador',
        pagina: 'asistencia.html',
        funciones: [
            'Estados: presente, tardanza, falta y justificado',
            'Marca de color por estado para leer la lista de un vistazo',
            'Justificaciones a cargo de auxiliares y coordinadores'
        ],
        reglas: 'Registro diario por sección',
        pasos: ['Elegir grado y sección', 'Marcar el estado de cada estudiante', 'Guardar el registro del día']
    },
    {
        id: 'notas',
        nombre: 'Notas',
        resumen: 'Calificaciones por bimestre para docentes.',
        descripcion: 'Los docentes registran las calificaciones de cada bimestre y el sistema indica quién aprueba.',
        imagen: 'notas.jpg',
        ancho: 1400, alto: 764,
        alt: 'Docente registrando calificaciones en el aula virtual',
        icono: 'fa-pen-to-square',
        audiencias: ['Docentes'],
        roles: 'Profesor',
        pagina: 'notas.html',
        funciones: [
            'Ingreso de notas por bimestre',
            'Escala de 0 a 20',
            'Las notas publicadas alimentan la libreta de cada familia'
        ],
        reglas: 'Nota aprobatoria: 11 sobre 20',
        pasos: ['Elegir curso y bimestre', 'Ingresar las calificaciones', 'Guardar y publicar']
    },
    {
        id: 'libreta',
        nombre: 'Libreta y pensiones',
        resumen: 'Libreta de notas, estado de cuenta y cronograma de pagos.',
        descripcion: 'Las familias consultan la libreta de su hijo, su estado de cuenta y el cronograma de pensiones desde el celular.',
        imagen: 'pagos.jpg',
        ancho: 1095, alto: 976,
        alt: 'Familias en la puerta del colegio',
        icono: 'fa-wallet',
        audiencias: ['Familias'],
        roles: 'Estudiante, Apoderado y Administrador',
        pagina: 'libreta.html',
        funciones: [
            'Libreta de notas por bimestre',
            'Estado de cuenta y cronograma de pagos',
            'Aviso claro cuando la libreta está bloqueada por pensiones pendientes'
        ],
        reglas: 'La libreta se bloquea con 2 meses o más de pensión pendiente',
        pasos: ['Ingresar con tu cuenta de apoderado o estudiante', 'Ver la libreta y el estado de cuenta', 'Revisar el cronograma de pagos'],
        destacado: true
    },
    {
        id: 'procesos',
        nombre: 'Convivencia escolar',
        resumen: 'Registro y seguimiento formativo.',
        descripcion: 'Registra incidencias y acuerdos de convivencia para dar un seguimiento formativo a cada estudiante.',
        imagen: 'convivencia.jpg',
        ancho: 1400, alto: 764,
        alt: 'Reunión de convivencia con padres de familia',
        icono: 'fa-scale-balanced',
        audiencias: ['Docentes', 'Administración'],
        roles: 'Administrador, Profesor, Auxiliar / Coordinador',
        pagina: 'procesos.html',
        funciones: [
            'Registro de incidencias y acuerdos',
            'Seguimiento formativo por estudiante',
            'Historial disponible para tutoría y coordinación'
        ],
        reglas: 'Enfoque formativo, no solo sancionador',
        pasos: ['Registrar la incidencia', 'Definir el acuerdo con la familia', 'Hacer el seguimiento']
    }
];

// Las páginas públicas viven en frontend/pages/, la portada en la raíz.
const RUTA_IMG = location.pathname.includes('/pages/') ? '../assets/img/' : 'frontend/assets/img/';

const CLASE_BADGE = {
    'Familias': 'badge--familias',
    'Docentes': 'badge--docentes',
    'Administración': 'badge--administracion'
};

// Escapa texto antes de insertarlo como HTML.
function esc(texto) {
    return String(texto).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// Tarjeta de un módulo (misma estructura que la galería de index.html).
function tarjetaModulo(m, nivel = 2) {
    const badges = m.audiencias.map(a => `<span class="badge ${CLASE_BADGE[a]}">${esc(a)}</span>`).join('');
    const titulo = m.destacado ? 'card-mod__title card-mod__title--featured' : 'card-mod__title';
    return `
    <div class="col-12 col-md-6 col-lg-4" data-audiencias="${esc(m.audiencias.join('|'))}">
        <article class="card-mod${m.destacado ? ' card-mod--destacada' : ''}">
            <div class="card-mod__media">
                <img class="card-mod__img" src="${RUTA_IMG}${esc(m.imagen)}" alt="${esc(m.alt)}" width="${m.ancho}" height="${m.alto}" loading="lazy" decoding="async">
                <span class="card-mod__icon" aria-hidden="true"><i class="fa-solid ${esc(m.icono)}"></i></span>
            </div>
            <div class="card-mod__body">
                <div class="card-mod__badges">${badges}${m.destacado ? '<span class="badge text-bg-warning">Recomendado para familias</span>' : ''}</div>
                <h${nivel} class="${titulo}">${esc(m.nombre)}</h${nivel}>
                <p class="card-mod__text">${esc(m.resumen)}</p>
                <a class="card-mod__link" href="producto.html?id=${encodeURIComponent(m.id)}" aria-label="Ver detalle de ${esc(m.nombre)}">Ver detalle <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></a>
            </div>
        </article>
    </div>`;
}
