// main.js
// Comportamiento común de las páginas públicas (index, catálogo, producto, login, registro).
// Requiere auth.js (sesión y roles) y, en la portada, formularios.js.

(function () {
    document.body.classList.add('js');
    const $ = (s) => document.querySelector(s);
    const $$ = (s) => Array.from(document.querySelectorAll(s));

    // ---------- Navbar según la sesión ----------
    const sesion = (typeof obtenerSesion === 'function') ? obtenerSesion() : null;
    const hayAcceso = sesion && PAGINAS_PERMITIDAS[sesion.rol];
    $$('[data-auth="out"]').forEach(el => { el.hidden = !!hayAcceso; });
    $$('[data-auth="in"]').forEach(el => { el.hidden = !hayAcceso; });
    const botonPortal = $('#btn-portal');
    if (hayAcceso && botonPortal) botonPortal.href = RUTA_PAGINAS + PAGINAS_PERMITIDAS[sesion.rol][0];
    const botonSalir = $('#btn-salir');
    if (botonSalir) botonSalir.addEventListener('click', e => { e.preventDefault(); cerrarSesion(); });

    // ---------- Fotos rotativas del hero (solo en la portada) ----------
    const fotos = $$('.hero__bg');
    if (fotos.length > 1) {
        const puntos = $$('.hero__dot');
        const botonPausa = $('#hero-pausa');
        const reducir = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        let actual = 0, temporizador = null, enPausa = reducir;

        function mostrar(k) {
            actual = (k + fotos.length) % fotos.length;
            fotos.forEach((f, j) => {
                f.classList.toggle('hero__bg--active', j === actual);
                f.setAttribute('aria-hidden', String(j !== actual));
            });
            puntos.forEach((p, j) => {
                p.classList.toggle('hero__dot--active', j === actual);
                if (j === actual) p.setAttribute('aria-current', 'true'); else p.removeAttribute('aria-current');
            });
        }
        function programar() {
            clearInterval(temporizador);
            if (!enPausa) temporizador = setInterval(() => mostrar(actual + 1), 7000);
        }
        function pausar(valor) {
            enPausa = valor;
            botonPausa.innerHTML = '<i class="fa-solid ' + (valor ? 'fa-play' : 'fa-pause') + '" aria-hidden="true"></i>';
            botonPausa.setAttribute('aria-label', valor ? 'Reanudar el cambio automático de fotos' : 'Pausar el cambio automático de fotos');
            programar();
        }

        puntos.forEach((p, j) => p.addEventListener('click', () => { mostrar(j); programar(); }));
        $('#hero-sig').addEventListener('click', () => { mostrar(actual + 1); programar(); });
        $('#hero-ant').addEventListener('click', () => { mostrar(actual - 1); programar(); });
        botonPausa.addEventListener('click', () => pausar(!enPausa));
        pausar(enPausa);   // con "reducir movimiento" empieza en pausa
    }

    // ---------- Pestañas Historia / Misión / Visión / Valores ----------
    $$('.tabs__btn').forEach(boton => boton.addEventListener('click', () => {
        $$('.tabs__btn').forEach(b => { b.classList.remove('tabs__btn--active'); b.setAttribute('aria-selected', 'false'); b.tabIndex = -1; });
        $$('.tabs__panel').forEach(p => p.classList.remove('tabs__panel--active'));
        boton.classList.add('tabs__btn--active');
        boton.setAttribute('aria-selected', 'true');
        boton.tabIndex = 0;
        $('#panel-' + boton.dataset.panel).classList.add('tabs__panel--active');
    }));
    // Flechas izquierda/derecha entre pestañas
    $$('.tabs__btn').forEach((boton, i, lista) => boton.addEventListener('keydown', e => {
        if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
        const sig = lista[(i + (e.key === 'ArrowRight' ? 1 : -1) + lista.length) % lista.length];
        sig.focus(); sig.click();
    }));

    // ---------- Aparecer al hacer scroll ----------
    if ('IntersectionObserver' in window) {
        const observador = new IntersectionObserver(entradas => entradas.forEach(e => {
            if (!e.isIntersecting) return;
            e.target.classList.add('v');
            observador.unobserve(e.target);
        }), { threshold: 0.15 });
        $$('.rv').forEach(el => observador.observe(el));
    } else {
        $$('.rv').forEach(el => el.classList.add('v'));
    }

    // ---------- Formulario de contacto (solo en la portada) ----------
    const form = $('#form-contacto');
    if (form) {
        const aviso = $('#estado-contacto');
        form.addEventListener('submit', async e => {
            e.preventDefault();
            aviso.className = 'form__status';
            aviso.textContent = '';
            if (!FormularioAccesible.validar(form)) return;

            aviso.textContent = 'Enviando…';
            try {
                const respuesta = await fetch('backend/api/contacto.php', { method: 'POST', body: new FormData(form) });
                const datos = await respuesta.json();
                if (!respuesta.ok || datos.ok === false) throw new Error(datos.mensaje || 'Error');
                aviso.classList.add('form__status--ok');
                aviso.textContent = 'Recibimos tu solicitud. Te responderemos pronto.';
                form.reset();
                FormularioAccesible.limpiar(form);
            } catch (error) {
                aviso.classList.add('form__status--error');
                aviso.textContent = 'No se pudo enviar: el servidor no está disponible. Intenta de nuevo más tarde.';
            }
        });
    }
})();
