// auth.js
// Control de acceso del prototipo + menú dinámico por rol.
// (Es una simulación en el navegador: la validación real iría en el backend.)

// Rutas relativas según estemos en la portada o dentro de frontend/pages/
const EN_PAGINAS = window.location.pathname.includes('/pages/');
const RAIZ = EN_PAGINAS ? '../../' : '';
const RUTA_PAGINAS = EN_PAGINAS ? '' : 'frontend/pages/';

const PAGINAS_PERMITIDAS = {
    ADMINISTRADOR: ['admision.html', 'matricula.html', 'asistencia.html', 'libreta.html', 'procesos.html', 'dashboard.html'],
    PROFESOR: ['asistencia.html', 'notas.html', 'procesos.html'],
    AUXILIAR: ['asistencia.html', 'procesos.html'],
    ESTUDIANTE: ['libreta.html'],
    APODERADO: ['libreta.html']
};

const NOMBRES_PAGINA = {
    'admision.html': 'Admisión',
    'matricula.html': 'Matrícula',
    'asistencia.html': 'Asistencia',
    'notas.html': 'Notas (Profesor)',
    'libreta.html': 'Libreta / Apoderados',
    'procesos.html': 'Convivencia',
    'dashboard.html': 'Dashboard'
};

function obtenerSesion() {
    try {
        const data = sessionStorage.getItem('usuarioActivo');
        return data ? JSON.parse(data) : null;
    } catch (e) {
        return null;
    }
}

function iniciarSesion(rol, codigo) {
    if (!PAGINAS_PERMITIDAS[rol]) return null;
    const sesion = {
        rol: rol,
        codigo: (codigo || 'invitado').trim(),
        fecha: new Date().toISOString()
    };
    try { sessionStorage.setItem('usuarioActivo', JSON.stringify(sesion)); } catch (e) { /* sin almacenamiento */ }
    return sesion;
}

function cerrarSesion() {
    try {
        localStorage.removeItem('sesionUsuario');
        sessionStorage.removeItem('usuarioActivo');
    } catch (e) { /* sin almacenamiento */ }
    window.location.href = RAIZ + 'index.html';
}

function paginaActual() {
    const partes = window.location.pathname.split('/');
    return partes[partes.length - 1] || 'index.html';
}

function protegerPagina() {
    const sesion = obtenerSesion();
    const actual = paginaActual();

    if (!sesion || !PAGINAS_PERMITIDAS[sesion.rol]) {
        window.location.href = RAIZ + 'frontend/pages/login.html';
        return false;
    }

    const permitidas = PAGINAS_PERMITIDAS[sesion.rol];
    if (!permitidas.includes(actual)) {
        alert('No tienes permiso para acceder a esta sección.');
        window.location.href = permitidas[0] || RAIZ + 'index.html';
        return false;
    }
    return true;
}

function pintarMenu() {
    const navLinks = document.getElementById('nav-links');
    if (!navLinks) return;

    const sesion = obtenerSesion();
    navLinks.innerHTML = '';

    function crearItem(texto, href, activo) {
        const a = document.createElement('a');
        a.className = 'navbar-item' + (activo ? ' is-active' : '');
        a.href = href;
        a.textContent = texto;
        navLinks.appendChild(a);
        return a;
    }

    if (!sesion || !PAGINAS_PERMITIDAS[sesion.rol]) {
        crearItem('Iniciar sesión', RAIZ + 'frontend/pages/login.html');
        return;
    }

    const permitidas = PAGINAS_PERMITIDAS[sesion.rol];
    const actual = paginaActual();

    crearItem('Inicio', RAIZ + 'index.html');

    permitidas.forEach(function (pagina) {
        crearItem(NOMBRES_PAGINA[pagina] || pagina, RUTA_PAGINAS + pagina, pagina === actual);
    });

    const info = document.createElement('span');
    info.className = 'navbar-item session-info';
    info.textContent = sesion.rol + ' · ' + sesion.codigo;
    navLinks.appendChild(info);

    const aSalir = crearItem('Cerrar sesión', '#');
    aSalir.classList.add('nav-salir');
    aSalir.addEventListener('click', function (e) {
        e.preventDefault();
        cerrarSesion();
    });
}

// Se llama al inicio de cada página interna.
function iniciarPagina() {
    protegerPagina();
    pintarMenu();
    if (typeof configurarMenuMovil === 'function') configurarMenuMovil();
}
