// catalogo.js · Listado de tarjetas con filtro por público y búsqueda (catalogo.html).
// Requiere catalogo-data.js.

(function () {
    const rejilla = document.getElementById('grid-catalogo');
    const contador = document.getElementById('contador');
    const buscador = document.getElementById('buscar');
    const botones = Array.from(document.querySelectorAll('[data-filtro]'));
    let filtro = 'Todos';

    function pintar() {
        const texto = buscador.value.trim().toLowerCase();
        const lista = MODULOS.filter(m =>
            (filtro === 'Todos' || m.audiencias.includes(filtro)) &&
            (m.nombre + ' ' + m.resumen).toLowerCase().includes(texto)
        );
        rejilla.innerHTML = lista.map(m => tarjetaModulo(m, 2)).join('') ||
            '<div class="col-12"><p class="alert alert-secondary mb-0">No encontramos servicios con esos criterios.</p></div>';
        contador.textContent = lista.length + (lista.length === 1 ? ' servicio' : ' servicios');
    }

    botones.forEach(b => b.addEventListener('click', () => {
        filtro = b.dataset.filtro;
        botones.forEach(x => {
            const activo = x === b;
            x.classList.toggle('catalog-filters__btn--active', activo);
            x.setAttribute('aria-pressed', String(activo));
        });
        pintar();
    }));
    buscador.addEventListener('input', pintar);

    // /catalogo.html?publico=Familias abre ya filtrado
    const inicial = new URLSearchParams(location.search).get('publico');
    const boton = botones.find(b => b.dataset.filtro === inicial);
    if (boton) boton.click(); else pintar();
})();
