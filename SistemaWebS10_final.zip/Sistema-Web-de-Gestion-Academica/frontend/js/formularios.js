// formularios.js
// Validación accesible de formularios (WCAG 2.1 AA).
// Cada campo tiene su <label>, aria-required y un mensaje con role="alert":
//   <input id="correo" aria-describedby="error-correo" aria-required="true" required>
//   <div id="error-correo" role="alert" hidden>Por favor ingrese un correo válido.</div>
// El mensaje se muestra al fallar y se oculta al corregir. Se asocia por id: "error-" + id del campo.

const FormularioAccesible = (function () {
    function campos(form) {
        return Array.from(form.querySelectorAll('input, select, textarea'))
            .filter(el => el.type !== 'submit' && el.type !== 'button' && el.type !== 'hidden');
    }

    function mensajeDe(el) {
        return document.getElementById('error-' + el.id);
    }

    // true si el campo es válido; muestra u oculta su mensaje
    function validarCampo(el) {
        const aviso = mensajeDe(el);
        let valido = el.checkValidity();

        // Regla extra: coincidencia con otro campo (confirmar contraseña)
        if (valido && el.dataset.igualA) {
            const otro = document.getElementById(el.dataset.igualA);
            valido = !!otro && el.value === otro.value;
        }

        el.setAttribute('aria-invalid', String(!valido));
        el.classList.toggle('form__control--invalid', !valido && el.type !== 'checkbox');
        if (aviso) aviso.hidden = valido;
        return valido;
    }

    // Valida todo el formulario; enfoca el primer campo con error.
    function validar(form) {
        let primero = null;
        campos(form).forEach(el => {
            if (!validarCampo(el) && !primero) primero = el;
        });
        activarEnVivo(form);
        if (primero) primero.focus();
        return !primero;
    }

    // Después del primer intento, el mensaje se actualiza mientras se escribe.
    function activarEnVivo(form) {
        if (form.dataset.enVivo) return;
        form.dataset.enVivo = '1';
        campos(form).forEach(el => {
            const evento = (el.tagName === 'SELECT' || el.type === 'checkbox') ? 'change' : 'input';
            el.addEventListener(evento, () => validarCampo(el));
            el.addEventListener('blur', () => validarCampo(el));
        });
    }

    function limpiar(form) {
        campos(form).forEach(el => {
            el.setAttribute('aria-invalid', 'false');
            el.classList.remove('form__control--invalid');
            const aviso = mensajeDe(el);
            if (aviso) aviso.hidden = true;
        });
    }

    return { validar: validar, validarCampo: validarCampo, limpiar: limpiar };
})();
