// producto.js · Ficha individual de un servicio (producto.html?id=libreta).
// Requiere catalogo-data.js.

(function () {
    const cont = document.getElementById('detalle');
    const id = new URLSearchParams(location.search).get('id');
    const m = MODULOS.find(x => x.id === id);

    if (!m) {
        document.title = 'Servicio no encontrado · I.E.P. San Jerónimo';
        cont.innerHTML = `
            <h1 class="detail__title">Servicio no encontrado</h1>
            <div class="alert alert-warning" role="alert">
                No encontramos ese servicio. <a href="catalogo.html" class="alert-link">Volver al catálogo</a>.
            </div>`;
        return;
    }

    document.title = m.nombre + ' · I.E.P. San Jerónimo';
    const badges = m.audiencias.map(a => `<span class="badge ${CLASE_BADGE[a]}">${esc(a)}</span>`).join(' ');
    const funciones = m.funciones.map(f => `<li><i class="fa-solid fa-circle-check" aria-hidden="true"></i><span>${esc(f)}</span></li>`).join('');
    const pasos = m.pasos.map((p, i) => `
        <div class="col-12 col-md-4">
            <div class="step">
                <span class="step__number" aria-hidden="true">${i + 1}</span>
                <h3 class="step__title">Paso ${i + 1}</h3>
                <p class="step__text">${esc(p)}</p>
            </div>
        </div>`).join('');
    const otros = MODULOS.filter(x => x.id !== m.id).slice(0, 3).map(x => tarjetaModulo(x, 3)).join('');

    cont.innerHTML = `
        <nav class="breadcrumb-nav" aria-label="Ruta de navegación">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="../../index.html">Inicio</a></li>
                <li class="breadcrumb-item"><a href="catalogo.html">Catálogo</a></li>
                <li class="breadcrumb-item active" aria-current="page">${esc(m.nombre)}</li>
            </ol>
        </nav>

        <div class="row g-5 align-items-start">
            <div class="col-12 col-lg-6">
                <div class="detail__media">
                    <img class="detail__img" src="${RUTA_IMG}${esc(m.imagen)}" alt="${esc(m.alt)}" width="${m.ancho}" height="${m.alto}">
                </div>
            </div>
            <div class="col-12 col-lg-6">
                <div>${badges}</div>
                <h1 class="detail__title">${esc(m.nombre)}</h1>
                <p class="detail__summary">${esc(m.descripcion)}</p>
                <ul class="detail__list">${funciones}</ul>
                <dl class="detail__specs">
                    <dt>Quién lo usa</dt><dd>${esc(m.roles)}</dd>
                    <dt>Regla del sistema</dt><dd>${esc(m.reglas)}</dd>
                    <dt>Nivel</dt><dd>Secundaria, 1.° a 5.° año</dd>
                </dl>
                <div class="detail__actions">
                    <a class="btn btn--accion btn--grande" href="login.html?next=${encodeURIComponent(m.pagina)}">Ingresar para usarlo</a>
                    <a class="btn btn--contorno-azul btn--grande" href="catalogo.html">Volver al catálogo</a>
                </div>
            </div>
        </div>

        <section class="mt-5 pt-4" aria-labelledby="como-se-usa">
            <h2 id="como-se-usa" class="landing-section__title mb-4">Cómo se usa</h2>
            <div class="row g-4">${pasos}</div>
        </section>

        <section class="mt-5 pt-4" aria-labelledby="otros">
            <h2 id="otros" class="landing-section__title mb-4">Otros servicios</h2>
            <div class="row g-4">${otros}</div>
        </section>`;
})();
