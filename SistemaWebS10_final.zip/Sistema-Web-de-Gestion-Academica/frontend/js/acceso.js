// acceso.js
// Login y registro del prototipo (simulación en el navegador).
// Requiere auth.js y formularios.js. En un sistema real, ambos pasos se validan en el servidor.

(function () {
    const estado = (el, texto, tipo) => {
        el.textContent = texto;
        el.className = 'form__status' + (tipo ? ' form__status--' + tipo : '');
    };

    // ---------- Login ----------
    const formLogin = document.getElementById('form-login');
    if (formLogin) {
        const aviso = document.getElementById('estado-login');

        // Si ya hay sesión, ir directo al portal
        const activa = obtenerSesion();
        if (activa && PAGINAS_PERMITIDAS[activa.rol]) {
            estado(aviso, 'Ya tienes una sesión abierta. Redirigiendo a tu portal…', 'ok');
            location.href = RUTA_PAGINAS + PAGINAS_PERMITIDAS[activa.rol][0];
        }

        formLogin.addEventListener('submit', e => {
            e.preventDefault();
            estado(aviso, '');
            if (!FormularioAccesible.validar(formLogin)) return;

            const rol = document.getElementById('rol').value;
            const sesion = iniciarSesion(rol, document.getElementById('codigo').value);
            if (!sesion) { estado(aviso, 'No se pudo iniciar sesión. Intenta de nuevo.', 'error'); return; }

            // ?next=notas.html solo se respeta si el rol tiene permiso para esa página
            const siguiente = new URLSearchParams(location.search).get('next');
            const permitidas = PAGINAS_PERMITIDAS[rol];
            const destino = permitidas.includes(siguiente) ? siguiente : permitidas[0];
            estado(aviso, 'Ingresando…', 'ok');
            location.href = RUTA_PAGINAS + destino;
        });
    }

    // ---------- Registro ----------
    const formRegistro = document.getElementById('form-registro');
    if (formRegistro) {
        const aviso = document.getElementById('estado-registro');
        const enlaceLogin = document.getElementById('ir-login');

        formRegistro.addEventListener('submit', e => {
            e.preventDefault();
            estado(aviso, '');
            enlaceLogin.hidden = true;
            if (!FormularioAccesible.validar(formRegistro)) return;

            // Simulación: no se guarda nada (ni la contraseña). El alta real iría al backend.
            const nombre = document.getElementById('nombres').value.trim();
            formRegistro.reset();
            FormularioAccesible.limpiar(formRegistro);
            estado(aviso, 'Cuenta creada para ' + nombre + '. Ya puedes iniciar sesión.', 'ok');
            enlaceLogin.hidden = false;
            enlaceLogin.focus();
        });
    }
})();
