# Sistema Web de Gestión Académica · I.E.P. San Jerónimo

Prototipo web para el nivel secundaria (1.° a 5.° año): admisión, matrícula, asistencia, notas, libreta con pensiones y convivencia escolar. Cada rol ve solo los módulos que le corresponden.

## Estructura del proyecto

```
Sistema-Web-de-Gestion-Academica/
├── index.html              Landing: navbar, hero, ¿por qué elegirnos?, galería, testimonios, contacto
├── README.md               Documentación del proyecto
├── frontend/               Capa de presentación (HTML / CSS / JS)
│   ├── css/
│   │   ├── style.css       Variables de :root (colores, fuentes, espaciados) y estilos de las páginas internas (Bulma)
│   │   ├── public.css      Páginas públicas: Bootstrap + componentes BEM
│   │   ├── animations.css  Keyframes y transiciones
│   │   └── responsive.css  Media queries
│   ├── js/
│   │   ├── main.js            Navbar según sesión, pestañas, scroll y contacto (páginas públicas)
│   │   ├── formularios.js     Validación accesible (aria-invalid, role="alert")
│   │   ├── acceso.js          Login y registro (simulados)
│   │   ├── catalogo-data.js   Datos de los servicios (única fuente)
│   │   ├── catalogo.js        Tarjetas, filtro y búsqueda
│   │   ├── producto.js        Ficha de un servicio
│   │   ├── dom.js, api.js, auth.js   Utilidades, fetch y sesión/roles
│   │   └── pages/             Un script por página interna
│   ├── assets/             img/, icons/, fonts/
│   └── pages/              catalogo, producto (?id=libreta), registro, login (públicas)
│                           admision, matricula, asistencia, notas,
│                           libreta, procesos, dashboard (requieren sesión)
├── backend/                Lógica del servidor (PHP)
│   ├── api/                config.php, contacto.php, datos.php
│   └── db/                 schema.sql, seed.sql
└── docs/                   Documentación y recursos
    ├── wireframes/  diagramas/  informe.pdf
    └── informe-frontend.md   Texto para el informe (BEM, Bootstrap, accesibilidad)
```

> Las páginas públicas cargan Bootstrap 5.3.3 y Font Awesome desde cdnjs; hace falta conexión a internet.

## Cómo ejecutarlo

**Solo el frontend:** abrir `index.html` con Live Server (VS Code) o con cualquier servidor estático, por ejemplo `python -m http.server` desde esta carpeta. Las páginas internas funcionan con datos de demostración.

**Con backend (formulario de contacto y datos):**

1. Importar `backend/db/schema.sql` y luego `backend/db/seed.sql` en MySQL/MariaDB.
2. Ajustar usuario y clave en `backend/api/config.php`.
3. Levantar PHP desde esta carpeta: `php -S localhost:8000`.
4. Abrir `http://localhost:8000/index.html`.

## Roles y módulos

| Rol | Módulos |
|---|---|
| Administrador | Admisión, matrícula, asistencia, libreta, convivencia, dashboard |
| Profesor | Asistencia, notas, convivencia |
| Auxiliar / Coordinador | Asistencia (justificaciones), convivencia |
| Estudiante / Apoderado | Libreta |

> El acceso y el registro son una simulación en el navegador (`sessionStorage`; el registro no guarda nada); en un sistema real ambos deben validarse en el servidor.

## Reglas de negocio implementadas

- **RN-03:** aforo máximo de 25 alumnos por sección.
- **RN-04:** la libreta se bloquea si hay 2 meses o más de pensión pendiente.
- Nota aprobatoria: 11 sobre 20.
