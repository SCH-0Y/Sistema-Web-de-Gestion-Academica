# Sistema Web de Gestión Académica · I.E.P. San Jerónimo

Prototipo web para el nivel secundaria (1.° a 5.° año): admisión, matrícula, asistencia, notas, libreta con pensiones y convivencia escolar. Cada rol ve solo los módulos que le corresponden.

## Estructura del proyecto

```
Sistema-Web-de-Gestion-Academica/
├── index.html              Portada y acceso al sistema
├── README.md               Documentación del proyecto
├── frontend/               Capa de presentación (HTML / CSS / JS)
│   ├── css/
│   │   ├── style.css       Estilos globales y variables
│   │   ├── animations.css  Keyframes y transiciones
│   │   ├── responsive.css  Media queries
│   │   └── home.css        Estilos propios de la portada
│   ├── js/
│   │   ├── main.js         Inicialización y eventos de la portada
│   │   ├── dom.js          Utilidades del DOM
│   │   ├── api.js          Llamadas fetch al backend
│   │   ├── auth.js         Sesión, roles y menú dinámico
│   │   └── pages/          Un script por página interna
│   ├── assets/
│   │   ├── img/            Imágenes del proyecto
│   │   ├── fonts/          Fuentes locales (si no se usa CDN)
│   │   └── icons/          Íconos SVG
│   └── pages/              admision, matricula, asistencia, notas,
│                           libreta, procesos, dashboard
├── backend/                Lógica del servidor (PHP)
│   ├── api/                config.php, contacto.php, datos.php
│   └── db/                 schema.sql, seed.sql
└── docs/                   Documentación y recursos
    ├── wireframes/         Bocetos previos
    ├── informe.pdf         Informe técnico
    └── diagramas/          Flujo de acceso y modelo de BD
```

## Cómo ejecutarlo

**Solo el frontend:** abrir `index.html` con Live Server (VS Code) o con cualquier servidor estático, por ejemplo `python -m http.server` desde esta carpeta. Las páginas internas funcionan con datos de demostración.

**Con backend (formulario de contacto y datos):**

1. Importar `backend/db/schema.sql` y luego `backend/db/seed.sql` en MySQL/MariaDB.
2. Ajustar usuario y clave en `backend/api/config.php`.
3. Levantar PHP desde esta carpeta: `php -S localhost:8000`.
4. Abrir `http://localhost:8000/index.html`.

## Roles y módulos

| Rol | Módulos |
|---|---|
| Administrador | Admisión, matrícula, asistencia, libreta, convivencia, dashboard |
| Profesor | Asistencia, notas, convivencia |
| Auxiliar / Coordinador | Asistencia (justificaciones), convivencia |
| Estudiante / Apoderado | Libreta |

> El acceso es una simulación en el navegador (`sessionStorage`); en un sistema real la autenticación debe validarse en el servidor.

## Reglas de negocio implementadas

- **RN-03:** aforo máximo de 25 alumnos por sección.
- **RN-04:** la libreta se bloquea si hay 2 meses o más de pensión pendiente.
- Nota aprobatoria: 11 sobre 20.
