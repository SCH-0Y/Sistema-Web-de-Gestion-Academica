<?php
// contacto.php · Recibe el formulario "Solicitar información" de la portada.
require __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    responder(['ok' => false, 'mensaje' => 'Método no permitido'], 405);
}

$nombre   = trim($_POST['nombre']   ?? '');
$correo   = trim($_POST['correo']   ?? '');
$telefono = trim($_POST['telefono'] ?? '');
$grado    = trim($_POST['grado']    ?? '');
$mensaje  = trim($_POST['mensaje']  ?? '');

if ($nombre === '' || !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
    responder(['ok' => false, 'mensaje' => 'Nombre y correo válidos son obligatorios'], 422);
}

try {
    $sql = 'INSERT INTO solicitudes_contacto (nombre, correo, telefono, grado_interes, mensaje)
            VALUES (:nombre, :correo, :telefono, :grado, :mensaje)';
    conectar()->prepare($sql)->execute([
        ':nombre'   => $nombre,
        ':correo'   => $correo,
        ':telefono' => $telefono,
        ':grado'    => $grado,
        ':mensaje'  => $mensaje,
    ]);
    responder(['ok' => true, 'mensaje' => 'Solicitud registrada']);
} catch (PDOException $e) {
    responder(['ok' => false, 'mensaje' => 'No se pudo guardar la solicitud'], 500);
}
