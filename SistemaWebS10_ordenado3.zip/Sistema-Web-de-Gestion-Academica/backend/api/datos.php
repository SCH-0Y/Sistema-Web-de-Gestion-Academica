<?php
// datos.php · Sirve datos en JSON al frontend.
// Uso: datos.php?recurso=postulantes  (también: alumnos, notas, pensiones, incidencias)
require __DIR__ . '/config.php';

$consultas = [
    'postulantes' => 'SELECT id, nombre, grado, tipo, fecha, estado FROM postulantes ORDER BY fecha DESC',
    'alumnos'     => 'SELECT a.id, a.codigo_matricula, a.apellidos, a.nombres, s.grado, s.seccion
                      FROM alumnos a JOIN secciones s ON s.id = a.seccion_id ORDER BY a.apellidos',
    'notas'       => 'SELECT a.codigo_matricula, a.apellidos, a.nombres, c.nombre AS curso, n.bimestre, n.nota, n.fecha_registro
                      FROM notas n JOIN alumnos a ON a.id = n.alumno_id JOIN cursos c ON c.id = n.curso_id
                      ORDER BY a.apellidos',
    'pensiones'   => 'SELECT alumno_id, concepto, monto_base, vencimiento, monto_pagado, estado FROM pensiones ORDER BY vencimiento',
    'incidencias' => 'SELECT a.codigo_matricula, a.apellidos, a.nombres, i.motivo, i.fecha
                      FROM incidencias i JOIN alumnos a ON a.id = i.alumno_id ORDER BY i.fecha DESC',
];

$recurso = $_GET['recurso'] ?? '';
if (!isset($consultas[$recurso])) {
    responder(['ok' => false, 'mensaje' => 'Recurso no válido'], 404);
}

try {
    $filas = conectar()->query($consultas[$recurso])->fetchAll();
    responder(['ok' => true, 'recurso' => $recurso, 'datos' => $filas]);
} catch (PDOException $e) {
    responder(['ok' => false, 'mensaje' => 'Error al consultar la base de datos'], 500);
}
