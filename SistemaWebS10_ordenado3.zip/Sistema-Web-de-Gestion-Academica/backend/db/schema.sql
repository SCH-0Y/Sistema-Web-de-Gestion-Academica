-- schema.sql · Estructura de tablas del Sistema de Gestión Académica
-- MySQL / MariaDB

CREATE DATABASE IF NOT EXISTS sanjeronimo CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sanjeronimo;

CREATE TABLE secciones (
    id        INT AUTO_INCREMENT PRIMARY KEY,
    anio      SMALLINT    NOT NULL,
    grado     VARCHAR(10) NOT NULL,          -- '1° Sec.' ... '5° Sec.'
    seccion   CHAR(1)     NOT NULL,
    aforo     TINYINT     NOT NULL DEFAULT 25, -- RN-03
    UNIQUE (anio, grado, seccion)
);

CREATE TABLE apoderados (
    id        INT AUTO_INCREMENT PRIMARY KEY,
    nombre    VARCHAR(120) NOT NULL,
    dni       CHAR(8)      NOT NULL UNIQUE,
    telefono  VARCHAR(20),
    correo    VARCHAR(120)
);

CREATE TABLE alumnos (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    codigo_matricula VARCHAR(15)  NOT NULL UNIQUE,
    apellidos        VARCHAR(80)  NOT NULL,
    nombres          VARCHAR(80)  NOT NULL,
    seccion_id       INT          NOT NULL,
    apoderado_id     INT,
    FOREIGN KEY (seccion_id)   REFERENCES secciones(id),
    FOREIGN KEY (apoderado_id) REFERENCES apoderados(id)
);

CREATE TABLE postulantes (
    id      INT AUTO_INCREMENT PRIMARY KEY,
    nombre  VARCHAR(120) NOT NULL,
    grado   VARCHAR(10)  NOT NULL,
    tipo    ENUM('NUEVO','TRASLADO') NOT NULL,
    fecha   DATE         NOT NULL,
    estado  ENUM('PENDIENTE','EN_EVALUACION','APROBADO') NOT NULL DEFAULT 'PENDIENTE'
);

CREATE TABLE cursos (
    id      INT AUTO_INCREMENT PRIMARY KEY,
    nombre  VARCHAR(60) NOT NULL UNIQUE
);

CREATE TABLE notas (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    alumno_id      INT          NOT NULL,
    curso_id       INT          NOT NULL,
    bimestre       TINYINT      NOT NULL,
    nota           DECIMAL(4,2) NOT NULL CHECK (nota BETWEEN 0 AND 20),
    fecha_registro DATE         NOT NULL,
    FOREIGN KEY (alumno_id) REFERENCES alumnos(id),
    FOREIGN KEY (curso_id)  REFERENCES cursos(id)
);

CREATE TABLE asistencias (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    alumno_id  INT  NOT NULL,
    curso_id   INT  NOT NULL,
    fecha      DATE NOT NULL,
    estado     ENUM('Presente','Tardanza','Falta','Justificado') NOT NULL,
    FOREIGN KEY (alumno_id) REFERENCES alumnos(id),
    FOREIGN KEY (curso_id)  REFERENCES cursos(id)
);

CREATE TABLE pensiones (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    alumno_id     INT           NOT NULL,
    concepto      VARCHAR(60)   NOT NULL,
    monto_base    DECIMAL(8,2)  NOT NULL,
    vencimiento   DATE          NOT NULL,
    monto_pagado  DECIMAL(8,2)  NOT NULL DEFAULT 0,
    estado        ENUM('PAGADO','PENDIENTE') NOT NULL DEFAULT 'PENDIENTE',
    FOREIGN KEY (alumno_id) REFERENCES alumnos(id)
);

CREATE TABLE incidencias (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    alumno_id  INT          NOT NULL,
    motivo     VARCHAR(200) NOT NULL,
    fecha      DATE         NOT NULL,
    FOREIGN KEY (alumno_id) REFERENCES alumnos(id)
);

CREATE TABLE solicitudes_contacto (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    nombre         VARCHAR(120) NOT NULL,
    correo         VARCHAR(120) NOT NULL,
    telefono       VARCHAR(20),
    grado_interes  VARCHAR(10),
    mensaje        TEXT,
    creado_en      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
