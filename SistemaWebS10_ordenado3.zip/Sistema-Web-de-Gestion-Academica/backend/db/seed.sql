-- seed.sql · Datos de prueba (los mismos que muestra el prototipo)
USE sanjeronimo;

INSERT INTO secciones (anio, grado, seccion) VALUES (2026,'1° Sec.','A'), (2026,'3° Sec.','B');

INSERT INTO apoderados (nombre, dni, telefono, correo) VALUES
('Rosa Rios de Aguilar', '41234567', '987000111', 'rosa.rios@example.com'),
('Mario Castro Peña',    '42345678', '987000222', 'mario.castro@example.com');

INSERT INTO alumnos (codigo_matricula, apellidos, nombres, seccion_id, apoderado_id) VALUES
('SEC-20261', 'Aguilar Rios',      'Pedro', 2, 1),
('SEC-20262', 'Castro Fernández',  'Lucia', 2, 2);

INSERT INTO postulantes (nombre, grado, tipo, fecha, estado) VALUES
('Carlos Mendoza', '1° Sec.', 'NUEVO',    '2026-01-10', 'PENDIENTE'),
('Ana Gómez',      '3° Sec.', 'TRASLADO', '2026-01-11', 'EN_EVALUACION'),
('Luis Paredes',   '5° Sec.', 'NUEVO',    '2026-01-12', 'APROBADO');

INSERT INTO cursos (nombre) VALUES ('Matemática'), ('Comunicación'), ('Ciencia');

INSERT INTO notas (alumno_id, curso_id, bimestre, nota, fecha_registro) VALUES
(1, 1, 1, 14, '2026-05-20'),
(2, 1, 1, 10, '2026-05-20');

INSERT INTO asistencias (alumno_id, curso_id, fecha, estado) VALUES
(1, 2, '2026-09-27', 'Presente'),
(2, 2, '2026-09-27', 'Falta');

INSERT INTO pensiones (alumno_id, concepto, monto_base, vencimiento, monto_pagado, estado) VALUES
(1, 'Cuota de ingreso 2026', 500.00, '2026-01-15', 500.00, 'PAGADO'),
(1, 'Pensión de marzo',      380.00, '2026-03-31', 380.00, 'PAGADO'),
(2, 'Pensión de abril + mayo', 760.00, '2026-05-31', 0.00, 'PENDIENTE');

INSERT INTO incidencias (alumno_id, motivo, fecha) VALUES
(1, 'Uso no autorizado de dispositivos en clase', '2026-05-20'),
(2, 'Justificación de inasistencia médica registrada', '2026-05-20');
