// procesos.js · Convivencia escolar
iniciarPagina();

$('#btn-guardar-proceso').addEventListener('click', function () {
    avisoEnBoton(this, 'Registro guardado');
});
