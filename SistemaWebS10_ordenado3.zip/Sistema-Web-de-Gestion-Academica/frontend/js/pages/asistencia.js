// asistencia.js · Registro y control de asistencia
iniciarPagina();

(function () {
    const sesion = obtenerSesion();
    if (!sesion) return;
    const descripcion = $('#rol-descripcion');
    if (sesion.rol === 'AUXILIAR') {
        $$('.solo-auxiliar').forEach(el => el.style.display = 'table-cell');
        $$('select.estado').forEach(el => el.disabled = true);
        ocultar($('#btn-guardar'));
        descripcion.textContent = 'Vista de Auxiliar/Coordinador: aprobación de justificación de inasistencias (RF-3.4)';
    } else {
        descripcion.textContent = 'Vista de Profesor: registro diario de asistencia por curso y sección (RF-3.1 a RF-3.3)';
    }
})();

const btnGuardar = $('#btn-guardar');
const resumen = $('#resumen-asistencia');

function pintarFila(select) {
    const fila = select.closest('tr');
    fila.classList.remove('estado-presente', 'estado-tardanza', 'estado-falta', 'estado-justificado');
    fila.classList.add('estado-' + select.value.toLowerCase());
}

function actualizarResumen() {
    const estados = $$('.estado');
    const cuenta = valor => estados.filter(e => e.value === valor).length;
    resumen.textContent = 'Registro actual: ' + cuenta('Presente') + ' presente(s), ' +
        cuenta('Tardanza') + ' tardanza(s) y ' + cuenta('Falta') + ' falta(s).';
}

$$('.estado').forEach(function (select) {
    pintarFila(select);
    select.addEventListener('change', function () {
        pintarFila(select);
        actualizarResumen();
    });
});
actualizarResumen();

btnGuardar.addEventListener('click', function () {
    try { localStorage.setItem('asistenciaDemo', JSON.stringify($$('.estado').map(s => s.value))); } catch (e) { /* sin almacenamiento */ }
    avisoEnBoton(btnGuardar, 'Asistencia guardada');
    actualizarResumen();
});

$$('.btn-aux').forEach(function (btn) {
    btn.addEventListener('click', function () {
        btn.textContent = 'Justificación aprobada';
        btn.disabled = true;
    });
});
