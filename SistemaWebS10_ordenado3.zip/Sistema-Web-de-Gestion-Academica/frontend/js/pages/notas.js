// notas.js · Registro de calificaciones (Profesor)
iniciarPagina();

const NOTA_MINIMA_APROBATORIA = 11;

function limitarNota(input) {
    input.value = input.value.replace(/[^0-9.]/g, '');
    const partes = input.value.split('.');
    if (partes.length > 2) input.value = partes[0] + '.' + partes.slice(1).join('');
    if (input.value !== '' && parseFloat(input.value) > 20) input.value = '20';
}

function redondear(input) {
    const texto = input.value.trim();
    if (texto === '') return;
    let numero = parseFloat(texto);
    if (isNaN(numero)) { input.value = ''; return; }
    numero = Math.min(20, Math.max(0, numero));
    input.value = Math.round(numero);
}

function actualizarEstado(input) {
    const numero = parseFloat(input.value);
    const estado = input.closest('tr').querySelector('.estado-nota');
    if (!estado || Number.isNaN(numero)) return;
    const aprobado = numero >= NOTA_MINIMA_APROBATORIA;
    estado.textContent = aprobado ? 'Aprobado' : 'Desaprobado';
    estado.classList.remove('is-success', 'is-danger', 'is-light');
    estado.classList.add(aprobado ? 'is-success' : 'is-danger', 'is-light');
}

document.addEventListener('input', function (e) {
    if (!e.target.classList.contains('input-nota')) return;
    limitarNota(e.target);
    actualizarEstado(e.target);
});

document.addEventListener('blur', function (e) {
    if (!e.target.classList.contains('input-nota')) return;
    redondear(e.target);
    actualizarEstado(e.target);
}, true);

// Enter pasa a la nota del siguiente alumno
document.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter' || !e.target.classList.contains('input-nota')) return;
    e.preventDefault();
    redondear(e.target);
    const todos = $$('.input-nota');
    const siguiente = todos[todos.indexOf(e.target) + 1];
    if (siguiente) siguiente.focus(); else e.target.blur();
});

$$('.input-nota').forEach(actualizarEstado);

$('#btn-guardar-notas').addEventListener('click', function () {
    try { localStorage.setItem('notasDemo', JSON.stringify($$('.input-nota').map(i => i.value))); } catch (e) { /* sin almacenamiento */ }
    avisoEnBoton(this, 'Cambios guardados');
});
