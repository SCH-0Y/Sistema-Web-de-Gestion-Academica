// admision.js · Panel de admisión y postulantes
iniciarPagina();

const tabla = $('#tabla-postulantes');
const filas = $$('#tabla-postulantes tr');

function aplicarFiltros() {
    const estado = $('#filtro-estado').value;
    const grado = $('#filtro-grado').value;
    filas.forEach(function (fila) {
        const textoEstado = fila.children[5]?.innerText.trim();
        const textoGrado = fila.children[2]?.innerText.trim();
        const visibleEstado = estado === 'todos' || textoEstado === estado;
        const visibleGrado = grado === 'todos' || textoGrado === grado;
        fila.style.display = visibleEstado && visibleGrado ? '' : 'none';
    });
}

$$('#filtro-estado, #filtro-grado').forEach(el => el.addEventListener('change', aplicarFiltros));

$$('.btn-accion').forEach(function (btn) {
    btn.addEventListener('click', function () {
        alert(btn.dataset.accion + ': ficha del postulante disponible para revisión.');
    });
});

$('#btn-nueva-solicitud').addEventListener('click', function () {
    const nombre = prompt('Nombre completo del nuevo postulante:');
    if (!nombre || !nombre.trim()) return;

    const fila = crear('tr');
    const celdas = ['NEW', nombre.trim(), '1° Sec.', 'NUEVO', new Date().toLocaleDateString('es-PE')];
    celdas.forEach(t => fila.appendChild(crear('td', {}, t)));

    const celdaEstado = crear('td');
    celdaEstado.appendChild(crear('span', { class: 'tag is-warning is-light' }, 'PENDIENTE'));
    fila.appendChild(celdaEstado);

    const celdaAccion = crear('td');
    const boton = crear('button', { type: 'button', class: 'button is-small is-link is-outlined btn-accion' }, 'Evaluar');
    boton.addEventListener('click', () => alert('Ficha de ' + nombre.trim() + ' lista para evaluación.'));
    celdaAccion.appendChild(boton);
    fila.appendChild(celdaAccion);

    tabla.appendChild(fila);
    filas.push(fila);
});
