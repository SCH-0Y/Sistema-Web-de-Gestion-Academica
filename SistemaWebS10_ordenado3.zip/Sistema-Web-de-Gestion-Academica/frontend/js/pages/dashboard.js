// dashboard.js · Panel de control institucional
iniciarPagina();
