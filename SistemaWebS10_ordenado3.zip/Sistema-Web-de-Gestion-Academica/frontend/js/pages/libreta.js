// libreta.js · Libreta del estudiante y estado de pensiones (RN-04)
iniciarPagina();

let moroso = false;

$('#btn-simular').addEventListener('click', function () {
    moroso = !moroso;
    const tarjeta = $('#status-card');

    tarjeta.classList.toggle('is-success', !moroso);
    tarjeta.classList.toggle('is-danger', moroso);
    $('#status-texto').textContent = moroso
        ? 'Estado financiero: MOROSO (atraso ≥ 2 meses)'
        : 'Estado financiero: AL DÍA / SIN DEUDA PENDIENTE';

    $('#bloque-libreta').style.display = moroso ? 'none' : 'block';
    $('#bloque-bloqueo').style.display = moroso ? 'block' : 'none';
    $('#fila-pendiente').style.display = moroso ? 'table-row' : 'none';
    this.textContent = moroso ? 'Simular pago al día' : 'Simular atraso ≥ 2 meses (RN-04)';
});

$('#btn-descargar').addEventListener('click', () => alert('Descargando libreta en PDF (RF-5.3)'));
