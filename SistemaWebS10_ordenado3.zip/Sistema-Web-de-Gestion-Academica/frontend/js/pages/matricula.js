// matricula.js · Ficha de matrícula
iniciarPagina();

$('#btn-matricular').addEventListener('click', function () {
    const persona = $('#persona').value.trim();
    const seccion = $('#seccion');
    if (!persona) {
        alert('Ingrese o seleccione un alumno antes de registrar la matrícula.');
        return;
    }
    const disponibles = Number(seccion.value);
    if (disponibles <= 0) {
        alert('No hay vacantes disponibles en la sección seleccionada.');
        return;
    }
    if (!confirm('¿Registrar matrícula para ' + persona + '?')) return;

    try {
        localStorage.setItem('matriculaDemo', JSON.stringify({
            persona: persona,
            seccion: seccion.options[seccion.selectedIndex].text,
            fecha: new Date().toISOString()
        }));
    } catch (e) { /* sin almacenamiento */ }
    this.textContent = 'Matrícula registrada';
    this.classList.add('is-success');
    this.disabled = true;
});
