// main.js
// Inicialización y eventos de la portada (index.html).
// Es autónomo: funciona aunque dom.js, auth.js o api.js no se hayan cargado.
// (En las páginas internas esos archivos sí se usan.)

(function () {
    document.body.classList.add('js');

    // Ayudantes locales (no chocan con los de dom.js)
    const $ = (s) => document.querySelector(s);
    const $$ = (s) => Array.from(document.querySelectorAll(s));

    // Roles y páginas: se usan los de auth.js si existen
    const RUTA = 'frontend/pages/';
    const ROLES = (typeof PAGINAS_PERMITIDAS !== 'undefined') ? PAGINAS_PERMITIDAS : {
        ADMINISTRADOR: ['admision.html', 'matricula.html', 'asistencia.html', 'libreta.html', 'procesos.html', 'dashboard.html'],
        PROFESOR: ['asistencia.html', 'notas.html', 'procesos.html'],
        AUXILIAR: ['asistencia.html', 'procesos.html'],
        ESTUDIANTE: ['libreta.html'],
        APODERADO: ['libreta.html']
    };

    function leerSesion() {
        try { return JSON.parse(sessionStorage.getItem('usuarioActivo')); } catch (e) { return null; }
    }
    function guardarSesion(rol, codigo) {
        try {
            sessionStorage.setItem('usuarioActivo', JSON.stringify({
                rol: rol, codigo: (codigo || 'invitado').trim(), fecha: new Date().toISOString()
            }));
        } catch (e) { /* sin almacenamiento */ }
    }

    // ---------- Menú móvil ----------
    $('#btn-menu').addEventListener('click', () => $('#menu').classList.toggle('abierto'));
    $$('#menu a').forEach(a => a.addEventListener('click', () => $('#menu').classList.remove('abierto')));

    // ---------- Diapositivas de la portada ----------
    const diapositivas = $$('.diapositiva');
    const puntos = $('#puntos');
    let actual = 0;
    let temporizador;

    diapositivas.forEach((_, k) => {
        const p = document.createElement('i');
        p.addEventListener('click', () => ir(k));
        puntos.appendChild(p);
    });

    function ir(k) {
        actual = (k + diapositivas.length) % diapositivas.length;
        diapositivas.forEach((d, j) => d.classList.toggle('on', j === actual));
        Array.from(puntos.children).forEach((p, j) => p.classList.toggle('on', j === actual));
        clearInterval(temporizador);
        temporizador = setInterval(() => ir(actual + 1), 7000);
    }

    $('#sig').addEventListener('click', () => ir(actual + 1));
    $('#ant').addEventListener('click', () => ir(actual - 1));
    ir(0);

    // ---------- Pestañas Historia / Misión / Visión / Valores ----------
    $$('.pestana').forEach(boton => boton.addEventListener('click', () => {
        $$('.pestana').forEach(b => b.classList.remove('on'));
        $$('.panel').forEach(p => p.classList.remove('on'));
        boton.classList.add('on');
        $('#panel-' + boton.dataset.panel).classList.add('on');
    }));

    // ---------- Aparecer al hacer scroll ----------
    if ('IntersectionObserver' in window) {
        const observador = new IntersectionObserver(entradas => entradas.forEach(e => {
            if (!e.isIntersecting) return;
            e.target.classList.add('v');
            observador.unobserve(e.target);
        }), { threshold: 0.15 });
        $$('.rv').forEach(el => observador.observe(el));
    } else {
        $$('.rv').forEach(el => el.classList.add('v'));
    }

    // ---------- Acceso al sistema ----------
    const sesion = leerSesion();
    const hayAcceso = sesion && ROLES[sesion.rol];
    const modal = $('#modal');
    const abrirModal = () => modal.classList.add('on');
    const cerrarModal = () => modal.classList.remove('on');
    const botonIngresar = $('#btn-ingresar');

    if (hayAcceso) {
        botonIngresar.textContent = 'Ir a mi portal';
        botonIngresar.href = RUTA + ROLES[sesion.rol][0];
    } else {
        botonIngresar.addEventListener('click', e => { e.preventDefault(); abrirModal(); });
        // Los módulos del portal piden iniciar sesión primero
        $$('a[href$=".html"]').forEach(a => a.addEventListener('click', e => { e.preventDefault(); abrirModal(); }));
    }

    $('#cerrar-modal').addEventListener('click', cerrarModal);
    modal.addEventListener('click', e => { if (e.target === modal) cerrarModal(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') cerrarModal(); });

    $('#form-login').addEventListener('submit', e => {
        e.preventDefault();
        const rol = $('#rol').value;
        guardarSesion(rol, $('#codigo').value);
        location.href = RUTA + ROLES[rol][0];
    });

    // ---------- Formulario de contacto ----------
    const formContacto = $('#form-contacto');
    const aviso = $('#aviso-contacto');

    formContacto.addEventListener('submit', async e => {
        e.preventDefault();
        aviso.className = 'aviso-form';
        aviso.textContent = 'Enviando…';
        try {
            const respuesta = await fetch('backend/api/contacto.php', { method: 'POST', body: new FormData(formContacto) });
            const datos = await respuesta.json();
            if (!respuesta.ok || datos.ok === false) throw new Error(datos.mensaje || 'Error');
            aviso.classList.add('ok');
            aviso.textContent = 'Recibimos tu solicitud. Te responderemos pronto.';
            formContacto.reset();
        } catch (error) {
            aviso.classList.add('error');
            aviso.textContent = 'No se pudo enviar: el servidor no está disponible. Intenta de nuevo más tarde.';
        }
    });
})();
