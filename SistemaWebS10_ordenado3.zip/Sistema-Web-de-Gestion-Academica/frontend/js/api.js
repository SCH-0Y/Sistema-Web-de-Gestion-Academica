// api.js
// Llamadas fetch al backend PHP (backend/api/).
// Si el backend no está levantado (por ejemplo al abrir el sitio como
// archivos estáticos) las funciones devuelven { ok: false } y la página
// sigue funcionando con sus datos de demostración.

const API_BASE = (typeof RAIZ !== 'undefined' ? RAIZ : '') + 'backend/api/';

async function pedir(archivo, opciones = {}) {
    try {
        const respuesta = await fetch(API_BASE + archivo, opciones);
        const datos = await respuesta.json();
        return { ok: respuesta.ok && datos.ok !== false, datos: datos };
    } catch (error) {
        return { ok: false, datos: null, error: error };
    }
}

const api = {
    // GET datos.php?recurso=postulantes | alumnos | notas | pensiones ...
    obtener: function (recurso, filtros = {}) {
        const params = new URLSearchParams({ recurso: recurso, ...filtros });
        return pedir('datos.php?' + params.toString());
    },

    // POST contacto.php (formulario "Solicitar información")
    enviarContacto: function (formulario) {
        return pedir('contacto.php', { method: 'POST', body: new FormData(formulario) });
    }
};
