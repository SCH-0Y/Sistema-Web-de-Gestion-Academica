// dom.js
// Utilidades pequeñas para trabajar con el DOM.

const $ = (selector, contexto = document) => contexto.querySelector(selector);
const $$ = (selector, contexto = document) => Array.from(contexto.querySelectorAll(selector));

// Crea un elemento: crear('td', { class: 'x' }, 'texto')
function crear(etiqueta, atributos = {}, texto = '') {
    const el = document.createElement(etiqueta);
    Object.entries(atributos).forEach(([k, v]) => el.setAttribute(k, v));
    if (texto) el.textContent = texto;
    return el;
}

function mostrar(el, tipo = 'block') { if (el) el.style.display = tipo; }
function ocultar(el) { if (el) el.style.display = 'none'; }

// Cambia el texto de un botón un momento y lo devuelve a su valor original.
function avisoEnBoton(boton, mensaje, ms = 1800) {
    const original = boton.textContent;
    boton.textContent = mensaje;
    setTimeout(() => { boton.textContent = original; }, ms);
}

// Menú hamburguesa de Bulma (páginas internas).
function configurarMenuMovil() {
    $$('.navbar-burger').forEach(function (burger) {
        const menu = document.getElementById(burger.dataset.target);
        if (!menu) return;

        function alternar(abierto) {
            burger.classList.toggle('is-active', abierto);
            menu.classList.toggle('is-active', abierto);
            burger.setAttribute('aria-expanded', String(abierto));
            burger.setAttribute('aria-label', abierto ? 'Cerrar menú' : 'Abrir menú');
        }

        burger.addEventListener('click', () => alternar(!menu.classList.contains('is-active')));
        menu.addEventListener('click', (e) => {
            if (e.target.closest('a.navbar-item')) alternar(false);
        });
    });
}
